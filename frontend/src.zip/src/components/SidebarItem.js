import React from "react";
import "../styles/SidebarItem.css";

const SidebarItem = ({ menu }) => {
  return (
    <div className="sidebar-item">
      {menu.image && (
          <img src={menu.image} alt={menu.name} style={{ width: "25px", height: "25px", marginRight: "10px" }} />
      )}
      <p>{menu.name}</p>
    </div>
  );
};

export default SidebarItem;
