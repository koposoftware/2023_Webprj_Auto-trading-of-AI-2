import "../styles/Spinner.css";

const Spinner = () => {
  return <span class="loader"></span>;
};

export default Spinner;
